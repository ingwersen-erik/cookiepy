# -*- coding: utf-8 -*-
"""Top-level package for {{ cookiecutter.friendly_name }}."""

__author__ = '{{ cookiecutter.author }}'
__email__ = '{{ cookiecutter.email }}'
__version__ = '{{ cookiecutter.version }}'
