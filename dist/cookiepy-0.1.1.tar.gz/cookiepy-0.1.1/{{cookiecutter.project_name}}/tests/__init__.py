"""Test suite for the {{cookiecutter.package_name}} package."""
